#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include "matrix.h"

matrix_t *matrix_init(unsigned nrows, unsigned ncols) {
    matrix_t *mat = malloc(sizeof(matrix_t));
    if (mat == NULL) {
        return NULL;
    }
    mat->data = malloc(nrows * sizeof(int *));
    if (mat->data == NULL) {
        free(mat);
        return  NULL;
    }

    for (int i = 0; i < nrows; i++) {
        mat->data[i] = malloc(ncols * sizeof(int));
        if (mat->data[i] == NULL) {
            // Need to free previously allocated matrix rows
            for (int j = 0; j < i; j++) {
                free(mat->data[j]);
            }
            free(mat->data);
            free(mat);
            return NULL;
        }
    }
    mat->nrows = nrows;
    mat->ncols = ncols;

    return mat;
}

void matrix_free(matrix_t *mat) {
        for (int i = 0; i < mat->nrows; i++) {
            free(mat->data[i]);
            }
            free(mat->data);
            free(mat);
    }

void matrix_put(matrix_t *mat, unsigned i, unsigned j, int val) {
    if (mat == NULL) {
        printf("Error: There is no active matrix\n");
    }
    else{mat->data[i][j] = val;}
}

int matrix_get(const matrix_t *mat, unsigned i, unsigned j) {
    if (mat == NULL) {
        printf("Error: There is no active matrix\n");
        return 0;
    }
    else{
        return mat->data[i][j];
    }

}

long matrix_sum(const matrix_t *mat) {
    long sum = 0;
    if (mat == NULL) {
        printf("Error: There is no active matrix\n");
        return 0;
    }
    else{
        for (int i = 0; i < mat->nrows; i++) {
            for (int j = 0; j < mat->ncols; j++) {
                sum += mat->data[i][j];
            }
        }
        return sum; 
    }
}

int matrix_max(const matrix_t *mat) {
    int maxnum = 0;
    if (mat == NULL) {
        printf("Error: There is no active matrix\n");
        return 0;
    }
    else{
        for (int i = 0; i < mat->nrows; i++) {
            for (int j = 0; j < mat->ncols; j++) {
                if(mat->data[i][j] > maxnum){
                    maxnum = mat->data[i][j];
                }
            }
        }
        return maxnum; 
    }
}


int matrix_write_text(const matrix_t *mat, const char *file_name) {
    FILE *f = fopen(file_name, "w");
    if (f == NULL) {
        return -1;
    }

    fprintf(f, "%u %u\n", mat->nrows, mat->ncols);
    for (int i = 0; i < mat->nrows; i++) {
        for (int j = 0; j < mat->ncols; j++) {
            fprintf(f, "%d ", mat->data[i][j]);
        }
        fprintf(f, "\n");
    }

    fclose(f);
    return 0;
}

matrix_t *matrix_read_text(const char *file_name) {
        FILE *fh = fopen(file_name, "r");
        if (fh == NULL){
        printf("Failed to read matrix from text file\n");
        return NULL;
        }
        else{
            matrix_t *mat = malloc(sizeof(matrix_t));
            if (mat == NULL) {
                return NULL;
            }
            int nrows;
            int ncols;
            fscanf(fh, "%d %d", &nrows, &ncols); 
            mat->data = malloc(nrows * sizeof(int *));
            if (mat->data == NULL) {
                fclose(fh);
                free(mat);
                return  NULL;
            }
            for (int i = 0; i < nrows; i++) {
                mat->data[i] = malloc(ncols * sizeof(int));
                if (mat->data[i] == NULL) {
                    // Need to free previously allocated matrix rows
                    for (int j = 0; j < i; j++) {
                        free(mat->data[j]);
                    }
                    free(mat->data);
                    free(mat);
                    return NULL;
                }
            }
            mat->nrows = nrows;
            mat->ncols = ncols;
            for (int i = 0; i < mat->nrows; i++) {
                for (int j = 0; j < mat->ncols; j++) {
                fscanf(fh, "%d", &mat->data[i][j]); 
                }
            }
        printf("Matrix successfully read from text file\n"); 
        fclose(fh);
        return mat;   
        }            
}


int matrix_write_bin(const matrix_t *mat, const char *file_name) {
    FILE *f = fopen(file_name, "w");
    if (f == NULL) {
        return -1;
    }

    unsigned int nrows = mat->nrows;
    unsigned int ncols = mat->ncols;
    fwrite(&nrows, sizeof(unsigned int), 1, f);
    fwrite(&ncols, sizeof(unsigned int), 1, f);
    for (int i = 0; i < mat->nrows; i++) {
        for (int j = 0; j < mat->ncols; j++) {
            int val = mat->data[i][j];
            fwrite(&val, sizeof(int), 1, f);
        }
    }

    fclose(f);
    return 0;
}

matrix_t *matrix_read_bin(const char *file_name) {
    FILE *f = fopen(file_name, "r");
        if (f == NULL){
        printf("Failed to read matrix from binary file\n");
        return NULL;
        }
        else{
            matrix_t *mat = malloc(sizeof(matrix_t));
            if (mat == NULL) {
                fclose(f);
                return NULL;
            }
            unsigned int nrows;
            unsigned int ncols;
            fread(&nrows, sizeof(unsigned int), 1, f); 
            fread(&ncols, sizeof(unsigned int), 1, f); 
            mat->data = malloc(nrows * sizeof(int *));
            if (mat->data == NULL) {
                fclose(f);
                free(mat);
                return  NULL;
            }
            for (int i = 0; i < nrows; i++) {
                mat->data[i] = malloc(ncols * sizeof(int));
                if (mat->data[i] == NULL) {
                    // Need to free previously allocated matrix rows
                    for (int j = 0; j < i; j++) {
                        free(mat->data[j]);
                    }
                    free(mat->data);
                    free(mat);
                    return NULL;
                }
            }
            mat->nrows = nrows;
            mat->ncols = ncols;
            for (int i = 0; i < mat->nrows; i++) {
                for (int j = 0; j < mat->ncols; j++) {
                fread(&mat->data[i][j], sizeof(int), 1, f); 
                }
            }
        printf("Matrix successfully read from binary file\n"); 
        fclose(f);
        return mat;   
        }            
}
