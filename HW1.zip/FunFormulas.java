//Written by lenli005
import java.util.Scanner;
public class FunFormulas {

        public void sd() {
            double diameter = get_Input("Enter diameter of storm in miles: ");
            double timeLast = Math.sqrt(((Math.pow(diameter,3))/216));
            System.out.println("The storm will last: " + timeLast + " hours");
        }
        public void ls() {
            double secondsFlash = get_Input("Enter the number of seconds from the time you see lightning flash until you hear the thunder: ");
            double distance = 1100 * secondsFlash;
            System.out.println("You are: " + distance + " feet from the lightning strike");
        }

        public void wi() {
            double edgeInches = get_Input("Enter the length of one edge of the ice cube in inches: ");
            double weight = 0.033 * (Math.pow(edgeInches,3));
            System.out.println("The weight of the ice cube is: " + weight + " pounds");
        }

        public void dt() {
            double timeTraveled = get_Input("Enter the hour(s) traveled: ");
            double rateMPH = get_Input("Enter the rate in miles per hour: ");
            double distanceTraveled = timeTraveled * rateMPH;
            System.out.println("The distance traveled is: " + distanceTraveled + " miles");
        }

        public void sa() {
            double weightLBS = get_Input("Enter weight in pounds: ");
            double heightIN = get_Input("Enter height in inches: ");
            double weightKG = weightLBS * 0.4536;
            double heightCM = heightIN * 2.54;
            double BSA = (Math.sqrt((weightKG * heightCM))) / 60;
            System.out.println("Body surface area is: " + BSA + " square meters");
        }
        public double get_Input(String promptStr) {
            double inval = -1;
            Scanner s = new Scanner(System.in);
            while (true) {
                System.out.print(promptStr);
                inval = s.nextDouble();
                if (inval < 0) {
                    System.out.println("\nERROR: Please enter a non-negative number.\n");
                    continue;
                } else {
                    break;
                }
            }
            //		s.close();
            return inval;
        }


}
