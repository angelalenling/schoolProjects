//Written by lenli005
import java.util.Scanner;
public class ComputeBMI {
    public static void main(String[] args) {
        double weight;
        double height;
        ComputeBMI bmi = new ComputeBMI();
        Scanner s = new Scanner(System.in);
        System.out.println("Enter weight in pounds: ");
        weight = s.nextDouble();
        while (weight < 0) {
            System.out.println("Please enter a valid weight.");
            System.out.println("Enter weight in pounds: ");
            weight = s.nextDouble();
        }
        System.out.println("Enter height in inches: ");
        height = s.nextDouble();
        while (height < 0) {
            System.out.println("Please enter a valid height.");
            System.out.println("Enter height in inches: ");
            height = s.nextDouble();
        }
        System.out.println("For weight: " + weight + " pounds and height: " + height + " inches");
        System.out.println("The BMI is: " + bmi.calcBMI(weight, height));
        s.close();
    }

    public double calcBMI(double weight, double height) {
        return (703 * weight) / (height * height);
    }
}
