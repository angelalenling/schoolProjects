//Written by lenli005
import java.lang.Math;
public class WindChill {
    public static void main(String[] args){
        double temp;
        double windSpeed;
        double windChill;
        if (args.length == 2) {
            temp = Double.parseDouble(args[0]);
            windSpeed = Double.parseDouble(args[1]);
            windChill = windChillCalc(temp,windSpeed);
            System.out.println("The wind chill at Temperature: " + temp + " degrees Fahrenheit and Wind speed: " + windSpeed + " mph is: " + windChill + " degrees Fahrenheit.");
        }
        else {
            System.out.println("Please only enter temperature and wind speed.");
        }
    }
    public static double windChillCalc(double temp, double windSpeed) {
        double windChill;

                windChill = 35.74 + (0.6215 * temp) - (35.75 * (Math.pow(windSpeed, 0.16))) + (0.4275 * temp * (Math.pow(windSpeed, 0.16)));
                return windChill;
    }

}
