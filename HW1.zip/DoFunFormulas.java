//Written by lenli005
import java.util.Objects;

public class DoFunFormulas {
    public static void main(String[] args){
        FunFormulas funFormulas = new FunFormulas();
        if (args.length != 1) {
            System.out.println("ERROR");
            for (String val : args)
                System.out.print(val + " ");
            System.out.print("is an invalid input, Type:\nsd compute storm distance\n" +
                    "ls to compute the distance to lightning strike\n" +
                    "wi to compute weight of ice cube\n" +
                    "dt to computer distance traveled\n" +
                    "sa to compute skin area ");
        }
        else if (Objects.equals(args[0], "sd")){
            funFormulas.sd();
        }
        else if (Objects.equals(args[0], "ls")){
            funFormulas.ls();
        }
        else if (Objects.equals(args[0], "wi")) {
            funFormulas.wi();
        }
        else if (Objects.equals(args[0], "dt")) {
            funFormulas.dt();
        }
        else if (Objects.equals(args[0], "sa")) {
            funFormulas.sa();
        }
        else {
            System.out.println("ERROR: Formula " + args[0] + " is not recognized, Type:\nsd compute storm distance\n" +
                    "ls to compute the distance to lightning strike\n" +
                    "wi to compute weight of ice cube\n" +
                    "dt to computer distance traveled\n" +
                    "sa to compute skin area ");
        }



        }
}
