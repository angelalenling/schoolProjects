// made by lenli005

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.io.*;

public class Wordle {
    ArrayList<String> wordsList = new ArrayList<>();
    Random rndm = new Random();
    ArrayList<String> guesses = new ArrayList<>();
    String alphabet = "ABCDEFGHI\nJKLMNOPQR\nSTUVWXYZ";
    boolean lostGame = true;

    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_GREEN_BACKGROUND = "\u001B[42m";
    public static final String ANSI_GRAY_BACKGROUND = "\u001B[100m";
    public static final String ANSI_YELLOW_BACKGROUND = "\u001B[43m";
    String greenLetters = ""; // used to keep track of guessed letters that are green in the wordle word.
    String usedLetters = ""; // used to keep track of letters guessed, but discludes letters that also appear in greenLetters


    public boolean duplicateCheck(String word, String letter){ // helper function to check for duplicate letter in the wordleWord
        int count = 0;
        boolean duplicateLetter = false;
        for (int i = 0; i < word.length(); i++){
            if (word.substring(i, i + 1).equals(letter)){
                count++;
                if (count > 1){
                    duplicateLetter = true;
                }
            }
        }
        return duplicateLetter;
    }


    public Wordle() throws IOException {
        File wordsInput = new File("sgb-words.txt");
        Scanner s = new Scanner(wordsInput);

        while (s.hasNextLine()) {
            wordsList.add(s.nextLine());
        }
        // randomly selected word from wordsList is set as solution (wordleWord)

        String wordleWord = wordsList.get(rndm.nextInt(wordsList.size()));
        wordsList.remove(wordleWord);
        wordleWord = wordleWord.toUpperCase();





            while (guesses.size() < 6) {


                System.out.println("Enter a 5 letter word: ");
                Scanner guessScan = new Scanner(System.in);
                String guess;
                System.out.println();


                guess = guessScan.next().toUpperCase();
                while (guess.length() != 5 || guess.matches(".*\\d.*")){ // method found on Geeksforgeeks
                    System.out.println("Invalid word. Please enter a 5 letter word.");    // asks user for input until they enter a valid word
                    System.out.println("Enter your guess: ");
                    guess = guessScan.next().toUpperCase();
                }

                    if (!guess.equals(wordleWord)){
                        String colorGuess = ""; // adds letters with color codes
                        String duplicateNotGreen = ""; // keeps track of double letters
                        for (int i = 0; i < 5; i++ ) {
                            if (guess.substring(i, i + 1).equals(wordleWord.substring(i, i + 1))){  // .substring method found on geeksforgeeks to split string
                                colorGuess += (ANSI_GREEN_BACKGROUND + guess.substring(i, i + 1) + ANSI_RESET);
                                greenLetters += guess.substring(i, i + 1); // adds green letter to string for later use when printing keyboard

                                if (!duplicateCheck(wordleWord, guess.substring(i, i + 1)) && duplicateCheck(guess, guess.substring(i, i + 1)) ){ // if wordleWord does not have duplicate letters and the guess does, adds the duplicate guessed letter to doubleLetters
                                    duplicateNotGreen += guess.substring(i, i + 1);
                                }
                            }
                            else if (wordleWord.contains(guess.substring(i, i + 1))) {    // checks for yellow letters
                                if (duplicateCheck(wordleWord, guess.substring(i, i + 1))) {
                                    //if wordleWord has duplicates and guess has
                                    // that letter, makes each occurrence yellow in colorGuess
                                    colorGuess += (ANSI_YELLOW_BACKGROUND + guess.substring(i, i + 1) + ANSI_RESET);
                                }
                                else if (!duplicateCheck(wordleWord, guess.substring(i, i + 1)) && duplicateCheck(guess, guess.substring(i, i + 1))) {
                                    // if wordleWord does not have duplicate letters
                                    // but the guess does, then only one of the guessed duplicate letters will appear yellow.
                                    if(!colorGuess.contains(guess.substring(i, i + 1))){
                                        colorGuess += (ANSI_YELLOW_BACKGROUND + guess.substring(i, i + 1) + ANSI_RESET);
                                    }
                                    else{
                                        colorGuess += (guess.substring(i, i + 1));
                                    }
                                }
                                else{
                                    // otherwise if no duplicates, letter appears yellow
                                    colorGuess += (ANSI_YELLOW_BACKGROUND + guess.substring(i, i + 1) + ANSI_RESET);
                                }
                            }
                            else if (duplicateNotGreen.contains(guess.substring(i, i + 1))){
                                // if one letter is green, then the second guess with that letter will not be green
                                colorGuess += (guess.substring(i, i + 1));
                            }
                            else {
                                colorGuess += (guess.substring(i, i + 1));
                                usedLetters += (guess.substring(i, i + 1));
                            }
                            }
                    guesses.add(colorGuess);
                    System.out.println();
                    for (int i = 0; i < guesses.size(); i++){
                        //prints previous guesses
                        System.out.println(guesses.get(i));
                    }
                    System.out.println();
                    String colorAlphabet = "";
                    for (int i = 0; i < 28; i ++) {
                        // prints alphabet with coordinated colors
                        if (greenLetters.contains(alphabet.substring(i, i + 1))) {
                            colorAlphabet += (ANSI_GREEN_BACKGROUND + alphabet.substring(i, i + 1) + ANSI_RESET);
                        } else if (usedLetters.contains(alphabet.substring(i, i + 1))){
                            if (!greenLetters.contains(alphabet.substring(i, i + 1))) {
                                colorAlphabet += (ANSI_GRAY_BACKGROUND + alphabet.substring(i, i + 1) + ANSI_RESET);
                            }
                            else {
                                continue;
                            }
                        } else {
                            colorAlphabet += alphabet.substring(i, i + 1);
                        }


                    }
                    System.out.println(colorAlphabet + "\n");
                    }
                    else {
                        System.out.println(ANSI_GREEN_BACKGROUND + wordleWord + ANSI_RESET); // used from stack overflow
                        System.out.println("Congrats! You won!");
                        lostGame = false;
                        break;
                    }
            }
            if (lostGame) {
                System.out.println("The word was: " + wordleWord);
                System.out.println("Nice try, better luck next time!");
            }
        File fout = new File("sgb-words.txt");
        FileOutputStream fos = new FileOutputStream(fout);
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
        for (int i = 0; i < wordsList.size(); ++i){
            bw.write(wordsList.get(i));
            bw.newLine();
        }
        bw.close();
        s.close();



    }


    public static void main(String[] args) throws IOException {
        Wordle game = new Wordle();



    }
}