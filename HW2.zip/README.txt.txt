User is prompted to enter 5 letter word (with special cases preventing numbers and non 5 letter words)
Word appears with green letters for correct spot, yellow for letters in the word but wrong spot, and no background color for letters not in the word.
The keyboard appears as described in homework instructions. 
Tested extra credit with word choices "hello" and "abbey" with guesses "level, label, rally, hunch, hoove" and "algae, keeps, orbit, abate, opens, babes, kebab, abyss" respectively.