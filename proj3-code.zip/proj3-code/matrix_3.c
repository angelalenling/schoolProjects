#include <limits.h>
#include <math.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>
#include "matrix.h"
#include <arpa/inet.h> //from https://wiki.sei.cmu.edu/confluence/display/c/POS39-C.+Use+the+correct+byte+ordering+when+transferring+data+between+systems#:~:text=The%20ntohl()%20function%20(network,architecture%2C%20ntohl()%20does%20nothing.

matrix_t *matrix_download_udp(const char *host, const char *port, const char *matrix_name) {
    #define BUFSIZE 1024
     
    struct addrinfo hints;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_DGRAM;
    struct addrinfo *server;

    int ret_val = getaddrinfo(host, port, &hints, &server);
    if (ret_val != 0) {
        fprintf(stderr, "getaddrinfo failed: %s\n", gai_strerror(ret_val));
        return NULL;
    }

    int sock_fd = socket(server->ai_family, server->ai_socktype, server->ai_protocol);
    if (sock_fd == -1) {
        perror("socket");
        freeaddrinfo(server);
        return NULL;
    }

    if (sendto(sock_fd, "lenli005", 8, 0, server->ai_addr, server->ai_addrlen) == -1) {
            perror("sendto");
            freeaddrinfo(server);
            close(sock_fd);
            return NULL;
        }

   if (sendto(sock_fd, matrix_name, strlen(matrix_name), 0, server->ai_addr, server->ai_addrlen) == -1) {
            perror("sendto");
            freeaddrinfo(server);
            close(sock_fd);
            return NULL;
        }

    int buf[BUFSIZE];
    int bytes_received;
    if ((bytes_received = recvfrom(sock_fd, buf, BUFSIZE * sizeof(int), 0, NULL, NULL)) == -1) {
        perror("recvfrom");
        freeaddrinfo(server);
        close(sock_fd);
        return NULL;
    }

    for(int i = 0; i < bytes_received / sizeof(int); i++){
        buf[i] = ntohl(buf[i]); // ntohl() from https://wiki.sei.cmu.edu/confluence/display/c/POS39-C.+Use+the+correct+byte+ordering+when+transferring+data+between+systems#:~:text=The%20ntohl()%20function%20(network,architecture%2C%20ntohl()%20does%20nothing.
    }

    if(buf[0] == 1){ //Failed to download
        freeaddrinfo(server);
        close(sock_fd);
        return NULL;
    }

    unsigned nrows = buf[1];
    unsigned ncols = buf[2];
    unsigned i = 0;
    unsigned j = 0;
    matrix_t *mat = matrix_init(nrows, ncols);

    int current_index = 3;
    for(i = 0; i < nrows; i++){
        for(j = 0; j < ncols; j++){
            matrix_put(mat, i, j, buf[current_index++]);
        }
    }
    freeaddrinfo(server);
    close(sock_fd);

    return mat;
}

matrix_t *matrix_download_tcp(const char *host, const char *port, const char *matrix_name) {

    struct addrinfo hints;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    struct addrinfo *server;

    int ret_val = getaddrinfo(host, port, &hints, &server);
    if (ret_val != 0) {
        fprintf(stderr, "getaddrinfo failed: %s\n", gai_strerror(ret_val));
        return NULL;
    }

    int sock_fd = socket(server->ai_family, server->ai_socktype, server->ai_protocol);
    if (sock_fd == -1) {
        perror("socket");
        freeaddrinfo(server);
        return NULL;
    }

    if (connect(sock_fd, server->ai_addr, server->ai_addrlen) == -1) {
        perror("socket");
        freeaddrinfo(server);
        return NULL;
    }
    freeaddrinfo(server);

    if (write(sock_fd, "lenli005", 8) == -1) {
        perror("write");
        close(sock_fd);
        return NULL;
    }

    if (write(sock_fd, matrix_name, strlen(matrix_name)) == -1) {
        perror("write");
        close(sock_fd);
        return NULL;
    }

    unsigned failed;
    unsigned nrows;
    unsigned ncols;

    read(sock_fd, &failed, sizeof(failed));
    failed = ntohl(failed);
    if(failed == 1){
        return NULL;
    }
    
    read(sock_fd, &nrows, sizeof(nrows));
    nrows = ntohl(nrows);
    read(sock_fd, &ncols, sizeof(ncols));
    ncols = ntohl(ncols);

    unsigned i = 0;
    unsigned j = 0;
    matrix_t *mat = matrix_init(nrows, ncols);

    for(i = 0; i < nrows; i++){
        for(j = 0; j < ncols; j++){
            unsigned add_data;
            read(sock_fd, &add_data, sizeof(add_data));
            add_data = ntohl(add_data);
            matrix_put(mat, i, j, add_data);
        }
    }

    close(sock_fd);
    return mat;
}
