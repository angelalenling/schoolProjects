#include <limits.h>
#include <math.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>
#include "matrix.h"

int matrix_parallel_sum(const matrix_t *mat, unsigned n_procs, int *result) {
    int elements = mat->nrows * mat->ncols; // total elements of matrix (m)
    double child_segment_size = ceil(((double)(elements)) / n_procs); // m(elements)/n(processes)-ceiling rounds up to the next largest decimal
    int my_pipe[2];
    if (pipe(my_pipe) == -1) { //error handling for pipe not opening
        perror("pipe\n");
        return -1;
    }
    *result = 0; //holds result
    for(int i = 0; i < n_procs; i++){ 
        pid_t pid = fork();
        if(pid == -1){ //error handling for child failing 
            perror("fork\n");
            return -1;
        }
        else if (pid == 0){ //if child, then close the write end of pipe
            close(my_pipe[0]);
            int starting_indx = i * (int)child_segment_size; //starting index is the current iteration * each child segment size
            int ending_indx = starting_indx + (int)child_segment_size; //ending index is the start index + the size of that segment 
            if (ending_indx > (mat->nrows * mat->ncols)){ //ensures that the ending index does not surpass the last element of the matrix
                ending_indx = mat->nrows * mat->ncols;
            }
            
            int this_process_sum = 0; //sets this childs sum to 0
            for (int index = starting_indx; index < ending_indx; index++){ //iterates over the segment created by this child with start and end indx
                int row = index / mat->ncols; // finds the row in the matrix being referred to (index / num of columns in matrix)
                int col = index % mat->ncols; // finds the col in the matrix being referred to (index % num of columns in matrix)
                this_process_sum = this_process_sum + mat->data[row][col]; // this val is added to this processes sum
            }


            write(my_pipe[1], &this_process_sum, sizeof(this_process_sum)); //sum is written to pipe
            exit(0); // end this process
        }
    }
    close(my_pipe[1]);
   
    for(int i = 0; i < n_procs; i++){
        wait(NULL); // waits for all child processes to finish before reading from them
    }
    int process_sum = 0; //initializes the sum to 0
    int total_sum = 0;  //initializes the total sum to 0
    for(int i = 0; i < n_procs; i++){  //reads the sums from each child and adds them to the total sum
        read(my_pipe[0], &process_sum, sizeof(process_sum));
        total_sum += process_sum;
    }
    *result = total_sum;
    close(my_pipe[0]); //closes read end of this pipe
    return 0;
    }



int matrix_parallel_max(const matrix_t *mat, unsigned n_procs, int *result) {
    int elements = mat->nrows * mat->ncols; // total elements of matrix (m)
    double child_segment_size = ceil(((double)(elements)) / n_procs); // m(elements)/n(processes)-ceiling rounds up to the next largest decimal
    int my_pipe[2];
    if (pipe(my_pipe) == -1) { //error handling for pipe not opening
        perror("pipe\n");
        return -1;
    }
    *result = 0; //holds result
    for(int i = 0; i < n_procs; i++){
        pid_t pid = fork();
        if(pid == -1){ //error handling for child failing 
            perror("fork\n");
            return -1;
        }
        else if (pid == 0){//if child, then close the write end of pipe
            close(my_pipe[0]);
            int starting_indx = i * (int)child_segment_size;//starting index is the current iteration * each child segment size
            int ending_indx = starting_indx + (int)child_segment_size; //ending index is the start index + the size of that segment
            if (ending_indx > (mat->nrows * mat->ncols)){//ensures that the ending index does not surpass the last element of the matrix
                ending_indx = mat->nrows * mat->ncols;
            }
            

            int this_process_max = 0;//sets this childs max to 0

            for (int index = starting_indx; index < ending_indx; index++){//iterates over the segment created by this child with start and end indx
                int row = index / mat->ncols;// finds the row in the matrix being referred to (index / num of columns in matrix)
                int col = index % mat->ncols;// finds the col in the matrix being referred to (index % num of columns in matrix)
                if (mat->data[row][col] > this_process_max){ // if this val is larger than the current max then updates the new max
                    this_process_max = mat->data[row][col];
                }
                
            }


            write(my_pipe[1], &this_process_max, sizeof(this_process_max));//sum is written to pipe
            exit(0);// end this process
        }
    }
    close(my_pipe[1]); //closes write end of pipe
    for(int i = 0; i < n_procs; i++){
        wait(NULL); // waits for all child processes to finish before reading from them
    } 
    int process_max = 0;//initializes the max to 0
    for(int i = 0; i < n_procs; i++){//reads the max from each child
        read(my_pipe[0], &process_max, sizeof(process_max));
        if(*result < process_max){ //if the next child's val is larger than the current, it updates the max
            *result = process_max;
        }
        }
    
    close(my_pipe[0]); //closes read end of the pipe
    return 0;
    }


